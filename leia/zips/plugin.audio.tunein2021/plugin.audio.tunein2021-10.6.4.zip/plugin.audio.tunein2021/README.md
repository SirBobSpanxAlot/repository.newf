TuneIn2021
==================
tunein.com-Addon für Kodi ([vormals Plugin für den Plexmediaserver](https://github.com/newf276/TuneIn2021)).


INSTALLATION:
===================  
### english:
- Download zip-file from https://github.com/newf276/repository.newf/leia/
- Download script.module.kodi-six.zip from https://github.com/romanvm/kodi.six/releases
- install downloaded zip-files with your Kodi-Browser
- start addon and make the appropriate settings
- [further instructions with pictures](https://kodi.wiki/view/HOW-TO:Install_add-ons_from_zip_files) 
