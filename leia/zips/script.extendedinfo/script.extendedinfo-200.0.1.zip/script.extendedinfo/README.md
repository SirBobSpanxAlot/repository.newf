Discover-Info, Kodi Add-on
Utilize Plugin.Video.Discovery for library integration and player files.
