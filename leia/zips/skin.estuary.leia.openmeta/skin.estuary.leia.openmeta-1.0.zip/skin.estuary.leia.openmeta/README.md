# skin.estuary.leia.openmeta

## My mod of the Kodi 18 (Leia) version of Estuary.

This is a very light modification that provides the following:
Use with OpenMeta, with Trakt enabled for Library.  Also needs new video nodes for OpenMeta.

<https://github.com/newf276/repository.newf>)
