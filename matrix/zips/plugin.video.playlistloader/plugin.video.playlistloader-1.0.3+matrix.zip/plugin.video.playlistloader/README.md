# plugin.video.playlistloader
M3U player for Kodi media centre
