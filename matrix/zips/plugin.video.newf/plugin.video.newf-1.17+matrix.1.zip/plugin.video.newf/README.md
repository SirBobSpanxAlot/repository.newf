# newf (plugin.video.newf)

newf is a multi-source addon for Kodi with the added ability to install custom provider modules. Unlike other Kodi addons which are generally built for a single service use, newf allows users to connect to multiple online/offline services at once for their viewing with a single click.

## License

Licensed under The GPL License.