# pornky.com addon for Kodi

_based on 'Simple example plugin for Kodi mediacenter'_

## License
- [GPLv3](http://www.gnu.org/copyleft/gpl.html)