# script.extendedinfo
extendedinfo Kodi Add-on
